import antlrarchivos.PlSqlLexer;
import antlrarchivos.PlSqlParser;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.IOException;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        // Ruta al archivo de entrada
        String inputFilePath = "C:\\Users\\Joab Ramirez\\Desktop\\Prueba1.txt";
        String outputFilePath = "C:\\Users\\Joab Ramirez\\Desktop\\Salida.txt";

        // Crear un analizador l�xico
        PlSqlLexer lexer = new PlSqlLexer(CharStreams.fromFileName(inputFilePath));

        // Crear un flujo de tokens para el analizador l�xico
        CommonTokenStream tokens = new CommonTokenStream(lexer);

        // Crear un analizador sint�ctico
        PlSqlParser parser = new PlSqlParser(tokens);

        // Iniciar el an�lisis sint�ctico desde la regla inicial
        ParseTree tree = parser.sql_statement();

        // Crear un escritor de archivos
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath));

        // Recorrer el �rbol de an�lisis sint�ctico y escribir los tokens y sus tipos
        writer.write("Token | Tipo\n");
        traverseTree(tree, parser, writer);

        // Cerrar el escritor de archivos
        writer.close();

        System.out.println("An�lisis sint�ctico completado. Resultados guardados en " + outputFilePath);
    }

    // M�todo para recorrer el �rbol de an�lisis sint�ctico y escribir los tokens y sus tipos
    private static void traverseTree(ParseTree tree, PlSqlParser parser, BufferedWriter writer) throws IOException {
        for (int i = 0; i < tree.getChildCount(); i++) {
            ParseTree child = tree.getChild(i);
            if (child instanceof TerminalNode) {
                Token token = ((TerminalNode) child).getSymbol();
                String tokenName = parser.getVocabulary().getSymbolicName(token.getType());
                String tokenText = token.getText();
                writer.write(tokenText + " | " + tokenName + "\n");
            } else {
                traverseTree(child, parser, writer);
            }
        }
    }
}
